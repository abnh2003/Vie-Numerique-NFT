// Script principal pour le site NFT "Le Jeu de la Vie de Conway"

// Animation des cellules en arrière-plan
function createCellAnimation() {
    const cellGrid = document.getElementById('cellAnimation');
    const gridWidth = window.innerWidth;
    const gridHeight = window.innerHeight;
    
    // Créer des cellules aléatoires
    for (let i = 0; i < 30; i++) {
        const cell = document.createElement('div');
        cell.classList.add('cell');
        
        // Position aléatoire
        const posX = Math.random() * gridWidth;
        const posY = Math.random() * gridHeight * 0.8; // Limiter à 80% de la hauteur
        
        cell.style.left = `${posX}px`;
        cell.style.top = `${posY}px`;
        
        // Délai aléatoire pour l'animation
        const delay = Math.random() * 5;
        cell.style.animationDelay = `${delay}s`;
        
        cellGrid.appendChild(cell);
    }
}

// Animation d'apparition au scroll
function handleScrollAnimation() {
    const fadeElements = document.querySelectorAll('.fade-in');
    
    fadeElements.forEach(element => {
        // Vérifier si l'élément est visible
        const elementTop = element.getBoundingClientRect().top;
        const elementVisible = 150;
        
        if (elementTop < window.innerHeight - elementVisible) {
            element.classList.add('appear');
        }
    });
}

// Gestion du loader
function handleLoader() {
    const loader = document.querySelector('.loader');
    
    // Cacher le loader après le chargement de la page
    window.addEventListener('load', () => {
        setTimeout(() => {
            loader.classList.add('hidden');
        }, 1500);
    });
}

// Données des NFTs (normalement chargées depuis une API ou un fichier JSON)
const nftData = [
    {
        id: 1,
        title: "Évolution de la Vie Numérique",
        generation: 1106,
        image: "preview.gif",
        video: "animation.mp4",
        description: "Simulation numérique inspirée des règles du Jeu de la Vie de John Conway, montrant l'évolution des motifs cellulaires à travers les générations avec des effets visuels uniques",
        author: "Manus AI",
        created: "2025-05-27",
        opensea_link: "https://opensea.io/",
        rarible_link: "https://rarible.com/",
        properties: {
            cells: 35,
            alive_cells: 28,
            density: "2.3%",
            generations: 1106,
            color_scheme: "niveaux de gris avec accents rouges"
        }
    },
    // D'autres NFTs peuvent être ajoutés ici
];

// Générer la galerie dynamiquement
function generateGallery() {
    const galleryGrid = document.querySelector('.gallery-grid');
    
    // Vider la galerie existante (sauf le premier élément qui est déjà codé en dur)
    const existingItems = galleryGrid.querySelectorAll('.gallery-item:not(:first-child)');
    existingItems.forEach(item => item.remove());
    
    // Ajouter des NFTs supplémentaires (simulés pour la démo)
    for (let i = 2; i <= 5; i++) {
        // Créer une copie du premier NFT avec des variations
        const nft = {
            ...nftData[0],
            id: i,
            generation: nftData[0].generation + i * 100,
            properties: {
                ...nftData[0].properties,
                alive_cells: Math.floor(Math.random() * 50) + 10,
                generations: nftData[0].properties.generations + i * 100
            }
        };
        
        const galleryItem = document.createElement('a');
        galleryItem.href = `nft-detail.html?id=${nft.id}`;
        galleryItem.classList.add('gallery-item', 'fade-in');
        
        galleryItem.innerHTML = `
            <img src="${nft.image}" alt="${nft.title}">
            <div class="gallery-overlay">
                <h3>${nft.title}</h3>
                <p>Génération #${nft.generation}</p>
                <span class="btn">Voir les détails</span>
            </div>
        `;
        
        galleryGrid.appendChild(galleryItem);
    }
}

// Fonction pour charger les détails d'un NFT spécifique
function loadNFTDetails() {
    // Vérifier si nous sommes sur la page de détails
    if (!window.location.pathname.includes('nft-detail.html')) return;
    
    // Récupérer l'ID du NFT depuis l'URL
    const urlParams = new URLSearchParams(window.location.search);
    const nftId = parseInt(urlParams.get('id')) || 1; // Par défaut, afficher le premier NFT
    
    // Trouver le NFT correspondant
    const nft = nftData.find(item => item.id === nftId) || nftData[0];
    
    // Mettre à jour le contenu de la page
    document.getElementById('nft-title').textContent = nft.title;
    document.getElementById('nft-description').textContent = nft.description;
    document.getElementById('nft-author').textContent = nft.author;
    document.getElementById('nft-created').textContent = new Date(nft.created).toLocaleDateString('fr-FR');
    
    // Mettre à jour les propriétés
    document.getElementById('nft-cells').textContent = nft.properties.cells;
    document.getElementById('nft-alive-cells').textContent = nft.properties.alive_cells;
    document.getElementById('nft-density').textContent = nft.properties.density;
    document.getElementById('nft-generations').textContent = nft.properties.generations;
    document.getElementById('nft-color-scheme').textContent = nft.properties.color_scheme;
    
    // Mettre à jour les liens d'achat
    document.getElementById('opensea-link').href = nft.opensea_link;
    document.getElementById('rarible-link').href = nft.rarible_link;
    
    // Mettre à jour les médias
    document.getElementById('nft-video').src = nft.video;
    document.getElementById('nft-image').src = nft.image;
}

// Initialisation
document.addEventListener('DOMContentLoaded', function() {
    createCellAnimation();
    handleLoader();
    generateGallery();
    loadNFTDetails();
    
    // Déclencher l'animation au chargement initial
    handleScrollAnimation();
    
    // Ajouter l'événement de scroll pour les animations
    window.addEventListener('scroll', handleScrollAnimation);
});
